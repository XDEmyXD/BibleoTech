<?php
session_start();
include('includes/config.php');
unset($_SESSION['signup']);

if (isset($_POST['confirmCode'])) {
    $verificationCode = isset($_POST['verificationCode']) ? $_POST['verificationCode'] : null;

    // Verifică dacă codul introdus are exact 6 cifre și conține doar cifre
    if ($verificationCode && strlen($verificationCode) == 6 && ctype_digit($verificationCode)) {
        $sql = "SELECT * FROM verification_codes WHERE VerificationCode = :code";
        $query = $dbh->prepare($sql);
        $query->bindParam(':code', $verificationCode, PDO::PARAM_INT);
        $query->execute();
        $result = $query->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $StudentId = $result['StudentId'];

            $updateSql = "UPDATE tblstudents SET Status = 2 WHERE StudentId = :StudentId";
            $updateQuery = $dbh->prepare($updateSql);
            $updateQuery->bindParam(':StudentId', $StudentId, PDO::PARAM_STR);
            $updateQuery->execute();

            $_SESSION['login'] = true;
            $_SESSION['StudentId'] = $StudentId;
            header('Location: index.php');
            exit();
        } else {
            echo '<script>alert("Invalid code. Please try again.")</script>';
        }
    } else {
        echo '<script>alert("Invalid verification code. Please enter a 6-digit numeric code.")</script>';
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
    <title>BiblioTech | Email Confirmation</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">Email Confirmation</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            CODE CONFIRMATION
                        </div>
                        <div class="panel-body">
                            <form name="codeConfirmation" method="post">
                                <div class="form-group">
                                    <label>Enter Verification Code</label>
                                    <input class="form-control" type="text" name="verificationCode" autocomplete="off" maxlength="6" required />
                                </div>
                                <button type="submit" name="confirmCode" class="btn btn-success">Confirm Code</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/custom.js"></script>
</body>
</html>
