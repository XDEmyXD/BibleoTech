<?php
session_start();
include('includes/config.php');
error_reporting(0);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:\xampp\htdocs\Library\Library\Library\PHPMailer-master\src\Exception.php';
require 'C:\xampp\htdocs\Library\Library\Library\PHPMailer-master\src\PHPMailer.php';
require 'C:\xampp\htdocs\Library\Library\Library\PHPMailer-master\src\SMTP.php';

ob_start();

function showConfirmationForm() {
    echo '<div class="panel panel-danger" id="confirmation-table">';
    echo '    <div class="panel-heading">';
    echo '        CODE CONFIRMATION';
    echo '    </div>';
    echo '    <div class="panel-body">';
    echo '        <form name="codeConfirmation" method="post">';
    echo '            <div class="form-group">';
    echo '                <label>Enter Verification Code</label>';
    echo '                <input class="form-control" type="text" name="verificationCode" autocomplete="off" required />';
    echo '            </div>';
    echo '            <button type="submit" name="confirmCode" class="btn btn-success">Confirm Code</button>';
    echo '        </form>';
    echo '    </div>';
    echo '</div>';
}

if (isset($_POST['signup']) && isset($_POST['confirmRegistration'])) {

    $count_my_page = ("studentid.txt");
    $hits = file($count_my_page);
    $hits[0]++;
    $fp = fopen($count_my_page, "w");
    fputs($fp, "$hits[0]");
    fclose($fp);
    $StudentId = $hits[0];

    $fname = $_POST['fullanme'];
    $mobileno = $_POST['mobileno'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $status = 1;

    $verificationCode = rand(100000, 999999);
    $_SESSION['verificationCode'] = $verificationCode;

    $mail = new PHPMailer(true);
    try {
        $mail->SMTPDebug = 3;
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'zamanemy2@gmail.com';
        $mail->Password   = 'beil kycl ybdg yjsy';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('from@example.com', 'Your Name');
        $mail->addAddress($email);

        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body    = 'Your verification code is: ' . $verificationCode;

        $mail->send();

        $sql = "INSERT INTO verification_codes(StudentId, VerificationCode) VALUES(:StudentId, :code)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':StudentId', $StudentId, PDO::PARAM_STR);
        $query->bindParam(':code', $verificationCode, PDO::PARAM_INT);
        $query->execute();

        $_SESSION['signup'] = true;

        ob_end_clean();
        header('Location: confirmation.php');
        exit();
    } catch (Exception $e) {
        echo '<script>alert("Error: Verification email could not be sent. Please try again later.")</script>';
    }

    $_SESSION['StudentId'] = $StudentId;

    $sql = "INSERT INTO tblstudents(StudentId,FullName,MobileNumber,EmailId,Password,Status) VALUES(:StudentId,:fname,:mobileno,:email,:password,:status)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':StudentId', $StudentId, PDO::PARAM_STR);
    $query->bindParam(':fname', $fname, PDO::PARAM_STR);
    $query->bindParam(':mobileno', $mobileno, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->bindParam(':status', $status, PDO::PARAM_STR);
    $query->execute();
    $lastInsertId = $dbh->lastInsertId();
    if (!$lastInsertId) {
        echo "<script>alert('Something went wrong. Please try again');</script>";
    }
}
ob_end_flush();
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
    <title>BiblioTech | Student Signup</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <script>
        function showConfirmationTable() {
            document.getElementById("confirmation-table").style.display = "block";
        }
    </script>
</head>
<body>
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row pad-botm">
                <div class="col-md-12">
                    <h4 class="header-line">User Signup</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-9 col-md-offset-1">
                    <div class="panel panel-danger">
                        <div class="panel-heading">
                            SINGUP FORMS
                        </div>
                        <div class="panel-body">
                            <?php if (!isset($_SESSION['signup']) || ($_SESSION['signup'] !== true && !isset($_POST['confirmRegistration']))): ?>
                                <form name="signup" method="post" onsubmit="return valid(); showConfirmationTable();">
                                    <div class="form-group">
                                        <label>Enter Full Name</label>
                                        <input class="form-control" type="text" name="fullanme" autocomplete="off" required />
                                    </div>
                                    <div class="form-group">
                                        <label>Mobile Number :</label>
                                        <input class="form-control" type="text" name="mobileno" maxlength="10" autocomplete="off" required />
                                    </div>
                                    <div class="form-group">
                                        <label>Enter Email</label>
                                        <input class="form-control" type="email" name="email" id="emailid" onBlur="checkAvailability()"  autocomplete="off" required  />
                                        <span id="user-availability-status" style="font-size:12px;"></span> 
                                    </div>
                                    <div class="form-group">
                                        <label>Enter Password</label>
                                        <input class="form-control" type="password" name="password" autocomplete="off" required  />
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm Password </label>
                                        <input class="form-control"  type="password" name="confirmpassword" autocomplete="off" required  />
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm Registration</label>
                                        <input class="form-control" type="checkbox" name="confirmRegistration" required />
                                    </div>
                                    <button type="submit" name="signup" class="btn btn-danger" id="submit">Register Now </button>
                                </form>
                            <?php else: ?>
                                <div class="alert alert-success">
                                    <strong>Registration Successful!</strong> An email with a verification code has been sent to your email address. Please check your email and enter the verification code to complete the registration.
                                </div>
                                <?php showConfirmationForm(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/custom.js"></script>
</body>
</html>